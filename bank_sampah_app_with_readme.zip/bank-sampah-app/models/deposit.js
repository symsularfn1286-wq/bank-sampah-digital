const { DataTypes, Model } = require('sequelize');

class Deposit extends Model {
  static initModel(sequelize) {
    Deposit.init({
      id: { type: DataTypes.INTEGER, autoIncrement: true, primaryKey: true },
      userId: { type: DataTypes.INTEGER },
      bankId: { type: DataTypes.STRING },
      materialType: DataTypes.STRING,
      weightKg: DataTypes.FLOAT,
      totalValue: DataTypes.INTEGER,
      photoUrl: DataTypes.STRING,
      status: { type: DataTypes.ENUM('pending','verified','rejected'), defaultValue: 'pending' },
      verifiedBy: DataTypes.INTEGER
    }, { sequelize, modelName: 'Deposit' });
    return Deposit;
  }
}

module.exports = Deposit;
