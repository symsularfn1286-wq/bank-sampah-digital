const { DataTypes, Model } = require('sequelize');

class Bank extends Model {
  static initModel(sequelize) {
    Bank.init({
      id: { type: DataTypes.STRING, primaryKey: true },
      name: DataTypes.STRING,
      address: DataTypes.STRING,
      lat: DataTypes.FLOAT,
      lng: DataTypes.FLOAT,
      contact: DataTypes.STRING
    }, { sequelize, modelName: 'Bank' });
    return Bank;
  }
}

module.exports = Bank;
