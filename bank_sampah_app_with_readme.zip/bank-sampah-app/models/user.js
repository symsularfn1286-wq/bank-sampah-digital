const { DataTypes, Model } = require('sequelize');
const bcrypt = require('bcrypt');

class User extends Model {
  static initModel(sequelize) {
    User.init({
      id: { type: DataTypes.INTEGER, autoIncrement: true, primaryKey: true },
      name: { type: DataTypes.STRING, allowNull: false },
      email: { type: DataTypes.STRING, allowNull: false, unique: true },
      passwordHash: { type: DataTypes.STRING, allowNull: false },
      role: { type: DataTypes.ENUM('user','petugas','admin'), defaultValue: 'user' },
      balance: { type: DataTypes.INTEGER, defaultValue: 0 }
    }, { sequelize, modelName: 'User' });

    User.prototype.verifyPassword = function(password) {
      return bcrypt.compare(password, this.passwordHash);
    };

    return User;
  }
}

module.exports = User;
