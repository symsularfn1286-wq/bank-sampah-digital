const { DataTypes, Model } = require('sequelize');

class Price extends Model {
  static initModel(sequelize) {
    Price.init({
      id: { type: DataTypes.INTEGER, autoIncrement: true, primaryKey: true },
      materialType: { type: DataTypes.STRING, allowNull: false },
      pricePerKg: { type: DataTypes.INTEGER, allowNull: false },
      active: { type: DataTypes.BOOLEAN, defaultValue: true }
    }, { sequelize, modelName: 'Price' });
    return Price;
  }
}

module.exports = Price;
