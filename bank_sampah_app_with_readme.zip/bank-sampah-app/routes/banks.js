const express = require('express');
const router = express.Router();
const { Bank, Price } = require('../models');

router.get('/', async (req, res) => {
  const banks = await Bank.findAll();
  res.json(banks);
});

router.get('/prices', async (req,res) => {
  const prices = await Price.findAll({ where: { active: true }});
  res.json(prices);
});

module.exports = router;
