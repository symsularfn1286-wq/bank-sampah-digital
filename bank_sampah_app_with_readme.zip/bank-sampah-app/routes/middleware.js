const jwt = require('jsonwebtoken');
const JWT_SECRET = process.env.JWT_SECRET || 'secret';

function auth(req,res,next) {
  const h = req.headers.authorization;
  if (!h) return res.status(401).json({ error: 'Tidak ada token' });
  try {
    const token = h.split(' ')[1];
    const payload = jwt.verify(token, JWT_SECRET);
    req.user = payload;
    next();
  } catch (e) { return res.status(401).json({ error: 'Token tidak valid' }); }
}

function requireRole(role) {
  return (req,res,next) => {
    if (!req.user) return res.status(401).json({ error: 'Unauthorized' });
    if (req.user.role !== role) return res.status(403).json({ error: 'Akses ditolak' });
    next();
  }
}

module.exports = { auth, requireRole };
