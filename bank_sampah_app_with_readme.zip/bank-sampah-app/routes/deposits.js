const express = require('express');
const router = express.Router();
const { auth } = require('./middleware');
const { Deposit, Price } = require('../models');
const path = require('path');

router.post('/', auth, async (req, res) => {
  try {
    const { bankId, materialType, weightKg } = req.body;
    const file = req.file;
    if (!bankId || !materialType || !weightKg) return res.status(400).json({ error: 'Lengkapi data' });
    const price = await Price.findOne({ where: { materialType, active: true }});
    const pricePerKg = price ? price.pricePerKg : 0;
    const totalValue = Math.round(parseFloat(weightKg) * pricePerKg);
    let photoUrl = null;
    if (file) {
      photoUrl = `/uploads/${path.basename(file.path)}`;
    }
    const deposit = await Deposit.create({
      userId: req.user.id,
      bankId,
      materialType,
      weightKg: parseFloat(weightKg),
      totalValue,
      photoUrl,
      status: 'pending'
    });
    res.json({ deposit });
  } catch (e) { console.error(e); res.status(500).json({ error: 'Server error' }); }
});

router.get('/', auth, async (req, res) => {
  const deposits = await Deposit.findAll({ where: { userId: req.user.id }, order: [['createdAt','DESC']]});
  res.json(deposits);
});

module.exports = router;
